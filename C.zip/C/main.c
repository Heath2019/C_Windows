#include<stdlib.h>


void clear(){
    system("CLS");
}


#include<stdio.h>
#include<string.h>
#include<windows.h>
#include"colors.h"
#include"test_pass.h"
#include"space_handling.h"
#include"books.h"
#include"clients.h"
#include"admin.h"
#include"read_book.h"
#include"menu.h"




main(){
	
	clear();
	menu();
	
}


