#include"md5.h"
#define lang 30


char *test_passwd(){
	char *p=(char*)malloc(sizeof(char)*lang);
	int i,j;
	char ch2;
	ch2='\0';
	
	
	for(i=0;i<lang;i++){
		ch2=getch();
		if(ch2==13) {
			 //Filter the enter button and break
			
			p[i]='\0';    
			ch2='\0';
			
			break;
	    }
	    
	    
	    else if(ch2<=0){
	    	//filter no ascii inputs
	    	
			p[i]='\0';
			ch2=getch();
			if(ch2==107) exit(0);   //-->  simulate alt+f4 (107)
			ch2='\0';
			i--;
			
			         }
			         
	
		
		
		
	    else if(ch2==8&&i>0){ 
		
		//filter the backspace button and simulate its effect until the start of password
			
			printf("\b \b");
			p[i-1]='\0';
			p[i]='\0';
			ch2='\0';
			i-=2;
			
		}
		else if(ch2>=33&&ch2<=126){
		
		//filter characters between ! (33) and ~ (126) 
		
		p[i]=ch2;
			
		printf("*");    //make the password invisible
		
			
			}
		else i--;  //in case of an abnormal character, we need to go back
		
	}
	p[i]='\0';   //turn the char after the last one into null in case of garbage
		
		if(p[0]!='\0'){
			
		unsigned *d=md5(p,strlen(p));
		unsigned char *md=(unsigned char*)malloc(sizeof(char)*16);
		int h=0;
	MD5union u;
	int k;
    
    char *f=(char*)malloc(sizeof(char)*33);
    
    for (i=0;i<4;i++){
        u.w = d[i];
        for (k=0;k<4;k++) {
        	md[h]=u.b[k];
        	h++;
		}
    }
    char *c=(char*)malloc(sizeof(char)*2);
    int j=0;
	for(i=0;i<16;i++){
		sprintf(c,"%02X",md[i]);   //copy hexadecimal to doubeled char using sprintf
		f[j]=c[0];
		if(j!=33)f[j+1]=c[1];
		j+=2;
	}
    printf("\n");
    f[32]='\0';
    
    free(md);
	
    return f;
	}
	return NULL;
}



