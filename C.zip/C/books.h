#define size 50
#define max_book 114
#define b_list "$ %d / %d / %lld / %s / %s / %d - %d - %d\n"
#define b_list_open "./books/books_list.txt"
#define description_line "/89/ Book Content! /89/\n"
#define desc_max 30

typedef struct book_date{  //book date structure
    int day,month,year;
}book_date;


typedef struct book{  //book structure
	int price;
	int number;
    long long int isbn;
    char *book_name;
    char *book_auteur;
    book_date publish_date;
}book;


int show_all_books(){  //show all the books in the library
	clear();
	FILE * p_book=fopen(b_list_open,"r");
	
	fseek(p_book,0,SEEK_END);
	int end=ftell(p_book);
	fseek(p_book,0,SEEK_SET);
	int set=ftell(p_book);
	if(set==end){
		color(0,6);
		printf("Empty Set!\n");
		color(0,15);
	}
	else{
	book tmp;
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	int i=1;
	int a,j;
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		
		
		_to_space(tmp.book_auteur);
		_to_space(tmp.book_name);
		
		
		a=i;
		j=0;
		while(a!=0){
			a/=10;
			j++;
		}
		printf("\n");
		for(a=0;a<j+10;a++){
			printf("-");
		}
		printf("\n");
		printf("| Book %d: |\n",i);
		for(a=0;a<j+10;a++){
			printf("-");
		}
		
		printf("\nNumber-> %d\nISBN->%lld\nBook Name-> %s\nBook Author-> %s\nPublish Date-> %d - %d - %d\nPrice:|%d|\n",tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price);
		printf("\n\n");
		i++;
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
    }
	fclose(p_book);
}


int set_book_number(){  //make the book's number auto increment
	return last_book_created()>last_book_deleted() ? last_book_created():last_book_deleted();
}


int last_book_created(){  //search for the biggest book number in existing books
	FILE * p_book=fopen(b_list_open,"r");
	
	fseek(p_book,0,SEEK_END);  
	int end=ftell(p_book);
	fseek(p_book,0,SEEK_SET);
	int set=ftell(p_book);
	if(set==end)return 1;  //test if the file is empty
	
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	int test=0;
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		if(test<tmp.number)test=tmp.number;
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p_book);
	return test+1;
}


int last_book_deleted(){  //search for the biggest book number in removed books
	FILE * p_book=fopen("./books/removed_books.txt","r");
	
	fseek(p_book,0,SEEK_END);
	int end=ftell(p_book);
	fseek(p_book,0,SEEK_SET);
	int set=ftell(p_book);
	if(set==end)return 1;  //test if the file is empty
	
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	int test=0;
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		if(test<tmp.number)test=tmp.number;
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p_book);
	return test+1;
}


char *set_book_file(int number){  //make the book's number like './books/biblio/number.txt'
	int i=0,k;
	char c[5];
	while(number!=0){
		c[i]=(char)(number%10+48);
		number/=10;
		i++;
	}
	number=i;
	int j;
	char f[9];
	
	for(j=number-1,i=0;j>=0,i<number;j--,i++){
		f[i]=c[j];
	}
	for(i=number;i<9;i++)f[i]='\0';
	
	for(i=0;i<number+4;i++){
		if(f[i]=='\0'){
			f[i]='.';
			f[i+1]='t';
			f[i+2]='x';
			f[i+3]='t';
			for(k=i+4;k<9;k++){
				f[k]='\0';
			}
			break;
		}
	}
	char *d=(char*)malloc(sizeof(char)*24);
	strcpy(d,"./books/biblio/");
	for(i=15;i<24;i++){
		d[i]=f[i-15];
	}
	return d;
}


char *set_book_cmt_file(int number){
	int i=0,k;
	char c[5];
	while(number!=0){
		c[i]=(char)(number%10+48);
		number/=10;
		i++;
	}
	number=i;
	int j;
	char f[18];
	
	for(j=number-1,i=0;j>=0,i<number;j--,i++){
		f[i]=c[j];
	}
	for(i=number;i<18;i++)f[i]='\0';
	
	for(i=0;i<number+4;i++){
		if(f[i]=='\0'){
			f[i]='_';
			f[i+1]='c';
			f[i+2]='o';
			f[i+3]='m';
			f[i+4]='m';
			f[i+5]='e';
			f[i+6]='n';
			f[i+7]='t';
			f[i+8]='s';
			f[i+9]='.';
			f[i+10]='t';
			f[i+11]='x';
			f[i+12]='t';
			for(k=i+13;k<18;k++){
				f[k]='\0';
			}
			break;
		}
	}
	char *d=(char*)malloc(sizeof(char)*35);
	strcpy(d,"./books/comments/");
	for(i=17;i<35;i++){
		d[i]=f[i-17];
	}
	return d;
}


int add_book_cmt_file(int number){
	char *d=set_book_cmt_file(number);
	FILE * p_book=fopen(d,"w");
	fclose(p_book);
	free(d);
	return 0;
}


char **write_description(){  //writing book's description
	
	char **mat=(char**)malloc(sizeof(char*)*desc_max);
	char ch2;
	int i=0,j;
	while(i<desc_max){
		j=0;
	mat[i]=(char*)malloc(sizeof(char)*max_book);
	
	while(j<=max_book){
		if(j==max_book-1){
			mat[i][j]='\0';
			break;
		}
    ch2=getch();
    
    
    if(ch2==8&&j>=0){  //filter the backspace and simulate its effect
    	
    	ch2='\0';
    	
    		if(j!=0) {
			printf("\b \b");
    		mat[i][j]='\0';
    		mat[i][j-1]='\0';
    		j-=2;}
			else j--;
    	
    	
	}
    
    
    else if(ch2=='$'){  //return when '$' is clicked
		ch2='\0';
		mat[i][j]='\0';
		while(mat[i+1]!=NULL)mat[i+1]=NULL;
		if(i==0&&j==0)mat[i]=NULL;
		return mat;
	}
		else if(ch2<=0){  //filter no ascii characters
			ch2=getch();
			if(ch2==107)exit(0);  //simulate effect of alt+f4
			j--;
		}
	
     
	
	else if(ch2>=32&&ch2<=126){   //store the characters between space and ~
		printf("%c",ch2);
	    mat[i][j]=ch2;
	}
	else if(ch2==13){  //return line when enter is clicked
		mat[i][j]='\0';
		ch2='\0';
		break;
	}
	
	
	j++;
	
	}
	printf("\n");
	i++;
	
                     }
return mat;
}


int add_book(){
	clear();
	int i;
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	if(tmp.book_auteur==NULL)return -1;
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	if(tmp.book_name==NULL)return -1;
	
	char *add=(char*)malloc(sizeof(char)*500);
	if(add==NULL)return -1;
	getchar();
	printf("Enter the Book's content Destination (Full)->\n");
	gets(add);
	for(i=0;i<100;i++){
		if(add[i]=='\0')break;
		if(add[i]=='\\')add[i]='/';
	}
	FILE * p_add=fopen(add,"r");
	free(add);
	if(p_add==NULL){
		color(0,6);
		printf("Book not found!!\n");
		color(0,15);
		fclose(p_add);
		return -1;
	}
	
	
	printf("Enter the name of the book: ");
	gets(tmp.book_name);
	
	
	space_to_(tmp.book_name); //space to +
	
	
	printf("Enter the name of the author: ");
	gets(tmp.book_auteur);
	
	
	space_to_(tmp.book_auteur); //space to +
	
	
	printf("ISBN: ");
	scanf("%lld",&tmp.isbn);
	printf("Publish Date:\n");
	printf("Year: ");
	scanf("%d",&tmp.publish_date.year);
	printf("Month: ");
	scanf("%d",&tmp.publish_date.month);
	printf("Day: ");
	scanf("%d",&tmp.publish_date.day);
	printf("Enter the Book's Price: ");
	scanf("%d",&tmp.price);
	tmp.number=set_book_number();
	
	
	FILE * p_book=fopen(b_list_open,"r+");
	fseek(p_book,0,SEEK_END);
	//add the book to the list
	fprintf(p_book,b_list,tmp.price,tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day);
	fclose(p_book);  //not worked when we started with an empty file
	
	
	free(tmp.book_auteur);
	free(tmp.book_name);
	
	
	
	char *c=set_book_file(tmp.number);
	add_book_file(c);  //create the book's file
	
	
	FILE * p_new=fopen(c,"r+");
	
	printf("\nBook's Description\n\n");
	printf("Note: Click On ($) to finish!\nMax lines (30)\n->");
	
	char **mat=write_description();
	i=0;
	//copy the description to the book's file
	while(mat[i]!=NULL){
		fprintf(p_new,"%s\n",mat[i]);
		i++;
	}
	fprintf(p_new,"%s",description_line);  //write a special sentence to split description from book's content
	
	char tmp2[max_book];
	while(fgets(tmp2,max_book,p_add)!=NULL){  //copy the book's content to the new file
		fseek(p_new,0,SEEK_END);
		
		fprintf(p_new,"%s",tmp2);
	}
	
	fclose(p_add);
	fclose(p_new);
	
	clear();
	
	color(0,2);
	printf("\nBook was Added Successfully!\n\n\n");
	color(0,15);
	
	add_book_cmt_file(tmp.number);
	
}


int add_book_file(char *book_des){  //write an emty file for the book
	FILE * p_add=fopen(book_des,"w");
	fclose(p_add);
}


int search_book(){
	clear();
	int choice;
	int number;
	printf("Book Search:\n");
	printf("(1)by number\n(2)by name\n->");
	scanf("%d",&choice);
	switch(choice){
		case 1: 
		printf("Enter the book's Number: ");
		int tmp_num;
		scanf("%d",&tmp_num);
		number=search_book_by_number(tmp_num); return number; break;
		case 2: search_book_by_name(); return 0; break;
		default: return 0; break;
	}
}


int search_book_by_number(int number){  //search book by its number
	
	
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	FILE * p_book=fopen(b_list_open,"r");
	while(!feof(p_book)){
		//compare the number with every line in the books list
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,
		&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		
		
		_to_space(tmp.book_auteur);  // + to space
		_to_space(tmp.book_name);   // + to space
		
		
		if(tmp.number==number){  //book is found
			
			
			
			printf("___________________\n\nNumber-> %d\nISBN-> %lld\nName-> %s\nAuthor-> "
			"%s\nPublish Date-> %d/%d/%d\nPrice->| %d |\n\n__________________\n\n",tmp.number,tmp.isbn,
			tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price);
			fclose(p_book);
	        free(tmp.book_auteur);
	        free(tmp.book_name);
			return number;  //return because the book's number is a private key
		}
	}
	fclose(p_book);
	free(tmp.book_auteur);
	free(tmp.book_name);
	
	clear();
	
	color(0,6);
	printf("\nNot Found!\n");
	color(0,15);
	
	return 0;
	
}


int search_book_by_name(){  //search book by name
	clear();
	char *name=(char*)malloc(sizeof(char)*size);
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	
	
	getchar();  //keyboard input
	
	printf("Enter the book's name: ");
	gets(name);
	 clear();
	
	space_to_(name);  //space to +
	
	
	FILE * p_book=fopen(b_list_open,"r");
	int count=0,i=1;
	//before showing results, count how much books are with the same name
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		if(strcmp(name,tmp.book_name)==0){
			count++;
		}
	}
	if(count==0){  //count=0 so no books found
		color(0,6);
		printf("Not Found!\n");
		color(0,15);
	}
	else{
	fseek(p_book,0,SEEK_SET);  //search and return to the brgining of file
	if(count>1){
		
		color(0,2);
		printf("\nWe've found %d Matches!\n\n\n",count);
		color(0,15);
	}
	
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		
		if(strcmp(name,tmp.book_name)==0){
			
			_to_space(tmp.book_auteur);  //+ to space
			_to_space(tmp.book_name);
			
			if(count==1){  //just one book found
				
				color(0,2);
				printf("\nWe've found One Match!\n\n\n");
				color(0,15);
				
				printf("Number-> %d\nISBN-> %lld\nName-> %s\nAuthor-> %s\nPublish Date-> %d/%d/%d\nPrice-> %d\n\n\n",tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price);
				break;
			}
			else {  //more than one book is found
				
				color(0,14);
				printf("\nMatch %d:\n\n",i);
				color(0,15);
				
				printf("Number-> %d\nISBN-> %lld\nName-> %s\nAuthor-> %s\nPublish Date-> %d/%d/%d\nPrice-> %d\n\n\n",tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price);
				i++;
			}
		}
	}
	}
	free(name);
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p_book);
	if(count!=0){  //telling user to search using number to be specific
		color(0,14);
		printf("Search using Book's number for more options!\n\n\n");
		color(0,15);
	}
}


int deleted_books(book deleted){  //add the deleted book to the removed_books list
	FILE * p_deleted=fopen("./books/removed_books.txt","r+");
	fseek(p_deleted,0,SEEK_END);
    fprintf(p_deleted,b_list,deleted.price,deleted.number,deleted.isbn,deleted.book_name,deleted.book_auteur,deleted.publish_date.year,deleted.publish_date.month,deleted.publish_date.day);
	fclose(p_deleted);
}


int delete_book_file(int number){  //delete book content
	
	char *c=set_book_file(number);
    remove(c);
    
    
    return 0;
}


int delete_book_cmt(int number){
	char*c=set_book_cmt_file(number);
	remove(c);
	free(c);
	return 0;
}


int delete_book_from_list(int number){  //remove book from the list
	int i=0;
	FILE * p_book=fopen(b_list_open,"r");
	FILE * p_new=fopen("./books/2books_list.txt","w+");
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		if(number==tmp.number){
			deleted_books(tmp);
			i++;
		}
		else{
			fprintf(p_new,b_list,tmp.price,tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day);
		}
	
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p_book);
	fclose(p_new);
	int rm=remove(b_list_open);
	if(rm!=0){
		color(0,4);
		printf("Unable to remove the book");
		color(0,15);
		
		return -1;
	}
	int ren=rename("./books/2books_list.txt",b_list_open);
	if(ren!=0){
		color(0,4);
		printf("Error! Try later\n");
		color(0,15);
		
		return -1;
	}
	if(i==0)return -1;
	return 0;
}


int delete_book(int a){  //delete the book from the list and its content
	clear();
	if(delete_book_from_list(a)==0) {
	delete_book_file(a);
	delete_book_cmt(a);
	color(0,2);
	printf("\nBook removed Successfully!\n\n");
	color(0,15);
    }    
	else {
		color(0,6);
		printf("\nBook not Found!!\n\n");
		color(0,15);
	}
	return 0;
}


int random_book(){
	int modulo=last_book_created();
	srand(time(0));
	int random=rand()%modulo;
	
	FILE *p_book=fopen(b_list_open,"r");
	int tmp_b,tmp=0;
	
	
	while(!feof(p_book)){
		fscanf(p_book,"$ %*s / %d / %*s / %*s / %*s / %*s - %*s - %*s\n",&tmp_b);
		if(random<tmp_b) break;
		if(random==tmp_b) return random;
	}
	fclose(p_book);
	return tmp_b;
}
