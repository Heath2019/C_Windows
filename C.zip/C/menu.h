//Main Menu
int menu(){
    int a,i;
    int loop=0;
    do{
	color(0,14);
	printf("(1)sign up\n(2)sign in\n(3)sign in as admin\n(4)Quit\n->");
	color(0,15);
    scanf("%d",&a);
    switch(a){
    	case 1: client_signup(); break;
    	case 2: client_portal(); break;
    	case 3: 
    	if(signed_in==1){  //if the session is active let the admin login without password
    		int a;
    		
    		color(0,2);
    		printf("Admin is already signed in!\nEnter Portal?  (1)yes  (2)no\n->");
    		scanf("%d",&a);
    		color(0,15);
    		
    		clear();
    		if(a==1) admin_portal();
    		else menu();
		}
		
		else admin_signin();
		
		break;
		case 4: exit(0); break;
    	default : 
		clear();
		color(0,6);
		printf("Please choose from the List!\n\n"); 
		break;
	}}while(loop==0);
	return 0;
}

