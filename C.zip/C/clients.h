#define credits 60
#define ch 30
#define clients_open "./clients/clients.txt"
#define comment_line "/89/comment!/89/\n"


typedef struct client{  //client structure
    int num_client;
    char *nom;
    char *prenom;
    char *username;
    char *password;
}client;


typedef struct comments{
	char *user;
	char **cmt;
	struct comments *next;
}comments;


char* complete_book_file(char *d){  //turn 'username' to 'username_books.txt'
	char *finish=(char*)malloc(sizeof(char)*(ch+26));
	char *c=(char*)malloc(sizeof(char)*(ch+10));
	strcpy(c,d);
	int i,j;
	for(i=0;i<ch+10;i++){
		if(c[i]=='\0'){
			c[i]='_';
			c[i+1]='b';
			c[i+2]='o';
			c[i+3]='o';
			c[i+4]='k';
			c[i+5]='s';
			c[i+6]='.';
			c[i+7]='t';
			c[i+8]='x';
			c[i+9]='t';
			for(j=i+10;j<ch+10;j++){
				c[j]='\0';
			}
			break;
		}
	}
	strcpy(finish,"./clients_books/");
	for(i=16;i<ch+26;i++){
		finish[i]=c[i-16];
	}
	return finish;
}


char *complete_credits_file(char *d){  //turn 'username' to 'username_credits.txt'
	char *finish=(char*)malloc(sizeof(char)*(ch+30));
	char *c=(char*)malloc(sizeof(char)*(ch+12));
	strcpy(c,d);
	int i,j;
	for(i=0;i<ch+12;i++){
		if(c[i]=='\0'){
			c[i]='_';
			c[i+1]='c';
			c[i+2]='r';
			c[i+3]='e';
			c[i+4]='d';
			c[i+5]='i';
			c[i+6]='t';
			c[i+7]='s';
			c[i+8]='.';
			c[i+9]='t';
			c[i+10]='x';
			c[i+11]='t';
			for(j=i+12;j<ch+12;j++){
				c[j]='\0';
			}
			break;
		}
	}
	strcpy(finish,"./clients_credits/");
	for(i=18;i<ch+30;i++){
		finish[i]=c[i-18];
	}
	return finish;
}



client *test_user(char *user){  //test if the client exits
    FILE * p_client;
    client *test=(client*)malloc(sizeof(client));
    test->username=(char*)malloc(sizeof(char)*ch);
	    p_client=fopen(clients_open,"r");
        while(!feof(p_client)){
            fscanf(p_client,"%*s / %*s / %*s / %s / %*s\n",test->username);  //%*s to ignore unused variables
            if(strcmp(user,test->username)==0){
            	fclose(p_client);
            	return test;
			}
        }
        fclose(p_client);
    free(test);
    return NULL;
}


client *accorder_client(char *user,char *pass){   //give access to client
	
    client *test=(client*)malloc(sizeof(client));
    test->password=(char*)malloc(sizeof(char)*33);
    test->username=(char*)malloc(sizeof(char)*ch);
    test->nom=(char*)malloc(sizeof(char)*ch);
    test->prenom=(char*)malloc(sizeof(char)*ch);
    FILE * p_client=fopen(clients_open,"r");
        while(!feof(p_client)){
            fscanf(p_client,"%d / %s / %s / %s / %s\n",&test->num_client,test->nom,test->prenom,test->username,test->password);
            if(strcmp(user,test->username)==0){
            	if(strcmp(pass,test->password)==0){
            		
            		fclose(p_client);
            		
            		return test;
				}
			}
        }
    fclose(p_client);
    free(test->password);
    free(test->username);
    free(test->nom);
   	free(test->prenom);
    free(test);
    return NULL;
}


client* client_signin(){  //client signin
	clear();
		char *user_login=(char*)malloc(sizeof(char)*ch);
		
		
		
		int try_again;
		do{
			getchar();
    	printf("Enter Username: ");
    	gets(user_login);
    	try_again=0;
    	if(test_user(user_login)==NULL){
    		
    		color(0,6);
    		printf("Username doesn't exist!\n");
    		color(0,14);
    		
    		printf("Try Again? (1)yes  (2)no\n->");
    		scanf("%d",&try_again);
    		color(0,15);
		}
		}while(try_again==1);
		
		
    	if(test_user(user_login)!=NULL)do{
    		printf("Enter Password: ");
    		char* pass_login=test_passwd();
    		if(pass_login==NULL){
    			clear();
    			return NULL;
			}
    		client *test=accorder_client(user_login,pass_login);
    		
    		if(test==NULL){
		
		color(0,6);
		printf("Password is Incorrect!\n");
		color(0,14);
		
		printf("Try Again? (1)yes  (2)no\n->");
		scanf("%d",&try_again);
		color(0,15);
		if(try_again==2)clear();
		}
		else {
			
			free(user_login);
		    
		    return test;
		}
		
		}while(try_again==1);
    		
			
		
		free(user_login);
		
		
		return NULL;
}


void client_portal(){  //enter the client's portal
	clear();
	
	client *clt=client_signin();
	
	if(clt!=NULL){
		clear();
		
	color(0,14);
	printf("Welcome Back %s!\n",clt->username);  //'welcome back username!'
	int i,a=strlen(clt->username);
	int choice;
	int loop=0;
	do{
		color(0,14);
		
	for(i=0;i<12+a;i++){
		printf("-");
	}
	printf("\n| %s Portal! |\n",clt->username);
	for(i=0;i<12+a;i++){
		printf("-");
	}
	printf("\n");
	printf("(1)show all my books\n(2)Show Credits\n(3)Read A Book\n(4)Show All Available Books\n(5)Buy A Book\n(6)Search in Library\n(7)search online\n(8)Discover\n(9)Select a random book\n(10)logout!\n->");
	scanf("%d",&choice);
	
	color(0,15);
	
	switch(choice){
		case 1: clear(); show_client_books(clt->username); break;
		case 2: show_client_credits(clt);break;
		case 3: allow_user_read(clt->username); break;
		case 4: show_all_books(); break;
		case 5: 
		printf("Enter Book's number: ");
		int num_book;
		scanf("%d",&num_book);
		buy_book(clt->username,num_book); break;
		case 6: search_offline(clt); break;
		case 7: 
		printf("");
		int number=search_book();
		
		search_online(clt,number);  
		break;
		case 8: Discover(clt); break;
		
		case 9: 
		printf("");
		
		
		int random=random_book();
		
		clear();
		search_online(clt,random); break;
		
		case 10: clear(); 
		
		color(0,2);
		printf("Logout successfull!\n");
		color(0,15);
		
		loop=1; break;
		default: clear(); 
		color(0,6);
		printf("Please Choose from the List!\n"); 
		color(0,15);
		
		break;
	}
	}while(loop==0);
	}
}


int is_user_allowed(char *user,int number){  //test if the client is allowed to read a book
	
	int i,j;
	char c[ch];
	strcpy(c,user);
	
	char *d=complete_book_file(c);
	
	FILE * p_client=fopen(d,"r");
	free(d);
	int num,progress;
	while(!feof(p_client)){
		fscanf(p_client,"%d / %d\n",&num,&progress);
		if(number==num){
			fclose(p_client);
			return progress;
		}
	}
	fclose(p_client);
	return 0;
}


int allow_user_read(char* user){  //use is_user_allowed fuction
	clear();
	int number;
	printf("Enter The book's Number: ");
	scanf("%d",&number);
	int progress=is_user_allowed(user,number);   
	
	if(progress==0){
		
		color(0,6);
		
		printf("You don't own this Book!\nBuy it Using Credits\n");
		
		color(0,15);
	}
	
	else {
		read_book(user,number,progress);
		
         }
}


int add_comment(char *user,int number){
	printf("You're writing a comment for the book number %d\n\n",number);
	printf("Note: Max lines: 30 / to finish writing press '$'\n\n");
	char *c=set_book_cmt_file(number);
	char **mat=write_description();
	FILE *p=fopen(c,"r+");
	fseek(p,0,SEEK_END);
	int i=0;
	fprintf(p,"/user/ %s /user/\n",user);
	while(mat[i]){
		fprintf(p,"%s\n",mat[i]);
		i++;
	}
	fprintf(p,"%s",comment_line);
	fclose(p);
	clear();
	
	color(0,2);
	printf("Comment Added Successfully!\n\n");
	color(0,2);
	fclose(p);
	return 0;
}


comments *ajouter_cmt_en_tete(comments *L,char *user,char **cmt){
	comments *nv=(comments*)malloc(sizeof(comments));
	nv->user=(char*)malloc(sizeof(char)*30);
	nv->cmt=(char**)malloc(sizeof(char*)*30);
	int i;
	strcpy(nv->user,user);
	for(i=0;i<30;i++){
		nv->cmt[i]=(char*)malloc(sizeof(char)*100);
		if(cmt[i])strcpy(nv->cmt[i],cmt[i]);
		else nv->cmt[i]=NULL;	
	}
	nv->cmt[i]=NULL;
	nv->next=L;
	return nv;
}


comments *init_cmt(comments *L){
	L=NULL;
	return L;
}


comments *scan_comments(FILE *p){
	char*tmp=(char*)malloc(sizeof(char)*100);
	char* user=(char*)malloc(sizeof(char)*30);
	char **mat=(char**)malloc(sizeof(char*)*30);
	int i;
	
	for(i=0;i<30;i++){
		mat[i]=(char*)malloc(sizeof(char)*100);
	}
	i=0;
	int j;
	comments *L=init_cmt(L);
	while(fgets(tmp,100,p)){
		if(strstr(tmp,"/user/")!=0){
			
			j=7;
			while(tmp[j]!=' '){
				user[j-7]=tmp[j];
				j++;
			}
			user[j-7]='\0';
			
		}
		else if(strcmp(tmp,"/89/comment!/89/\n")==0){
			mat[i]=NULL;
			i=0;
			L=ajouter_cmt_en_tete(L,user,mat);
		}
		else{
			
			strcpy(mat[i],tmp);
			
		    i++;
		}
		
	}
	return L;
}


int read_book_comments(int number){
	char *d=set_book_cmt_file(number);
	FILE *p=fopen(d,"r");
	free(d);
	fseek(p,0,SEEK_END);
	int end=ftell(p);
	fseek(p,0,SEEK_SET);
	int set=ftell(p);
	if(set==end){
		color(0,6);
		printf("This book has no comments!\n\n");
		color(0,15);
		return 1;
	}
	comments *L=init_cmt(L);
	L=scan_comments(p);
	int i;
	int choice;
	while(L){
		printf("\n\nUser: %s\n\n",L->user);
		printf("Comment: \n");
		i=0;
		while(L->cmt[i]){
			printf("%s",L->cmt[i]);
			i++;
		}
		printf("\n\n(1)Show next (2)Stop\n->");
		scanf("%d",&choice);
		if(choice==1){
			clear();
			L=L->next;
		}
		else {
			clear();
			break;
		}
	}
}


int search_offline_by_name(client *clt){
	clear();
	char name[size];
	getchar();
	printf("Enter The Book's Name: ");
	gets(name);
	space_to_(name);
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	
	char *c=complete_book_file(clt->username);
	
	FILE * p_client=fopen(c,"r");
	FILE * p_book=fopen(b_list_open,"r");
	int i=0;
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
		if(strcmp(name,tmp.book_name)==0){
			
			int tmp_num;
			fseek(p_client,0,SEEK_SET);
			
			while(!feof(p_client)){
				
				fscanf(p_client,"%d / %*s\n",&tmp_num);
			    if(tmp_num==tmp.number){
			    	printf("\nBook %d:\n",i+1);
			    	_to_space(tmp.book_auteur);
			    	_to_space(tmp.book_name);
			    	printf("Number-> %d\nISBN-> %lld\nName-> %s\nAuthor-> %s\nPublish Date-> %d/%d/%d\nPrice-> %d\n\n\n",tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price);
			    	i++;
				}
			    
			}
		}
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p_book);
	fclose(p_client);
	if(i!=0) printf("Search Using Book's Number for more Options!\n\n");
	else printf("Not Found!\n\n");
}


int search_offline_by_number(client *clt){
	clear();
	int number,tmp_number;
	printf("Enter The Book's Number: ");
	scanf("%d",&number);
	char *c=complete_book_file(clt->username);
	FILE *p_client=fopen(c,"r");
	while(!feof(p_client)){
		fscanf(p_client,"%d / %*s\n",&tmp_number);
		if(number==tmp_number){
			
			
			
			FILE *p_book=fopen(b_list_open,"r");
			book tmp;
			
			tmp.book_auteur=(char*)malloc(sizeof(char)*size);
			tmp.book_name=(char*)malloc(sizeof(char)*size);
			
			while(!feof(p_book)){
				fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);
				if(number==tmp.number){
					
					fclose(p_book);
					fclose(p_client);
					
					return number;
									
				}
			}
			
			fclose(p_book);
			
		}
	}
	
	fclose(p_client);
	printf("Not Found\n\n");
	return 0;
}


int search_offline(client *clt){
	clear();
	int choice;
	printf("(1)by number\n(2)by name\n->");
	scanf("%d",&choice);
	switch(choice){
		
	case 1: 
	printf("");
	int number=search_offline_by_number(clt); 
	if(number!=0)search_online(clt,number);
	break;
	
	case 2: search_offline_by_name(clt); break;
	}
}


int search_online(client *clt,int number){  //search a book online
	clear();
	if(number!=0){
		int choice;
		int stop=0;
		
		
		do{
			color(0,14);
		
		search_book_by_number(number);
			
		printf("\n----------------\n| Book Options |\n----------------\n\n");
		
		
		int a=is_user_allowed(clt->username,number);
		if(a==0) printf("(1)Buy\n(2)Read Description\n(3)Read Comments\n(4)Go Back\n->");
		
		else printf("(1)Read\n(2)Read Description\n(3)Read Comments\n(4)Go Back\n->");
		
		scanf("%d",&choice);
		
		color(0,15);
		
		clear();
		switch(choice){
			case 1: 
			if(a==0)buy_book(clt->username,number);
			else read_book(clt->username,number,a);
			break;
			case 2: read_description(number); break;
			case 3: read_book_comments(number); break;
			case 4: stop=1;break;
			default:  break;
		}
	      }while(stop==0);
	      return;
	}
	return;
}


int buy_book(char *user,int number){  //buy a book
	clear();
	char *c=complete_credits_file(user);
	char *d=complete_book_file(user);
	FILE * p_client_books2=fopen(d,"r");
	int test;
	while(!feof(p_client_books2)){
		fscanf(p_client_books2,"%d / %*s\n",&test);
		if(number==test){
			color(0,6);
			printf("You Already Own this Book!\n\n");
			color(0,15);
			fclose(p_client_books2);
			return 1;
		}
	}
	fclose(p_client_books2);
	int credits2;
	book tmp2;
	FILE * p_credits=fopen(c,"r");
	fscanf(p_credits,"%d\n",&credits2);
	fclose(p_credits);
	FILE * p_book=fopen(b_list_open,"r");
	tmp2.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp2.book_name=(char*)malloc(sizeof(char)*size);
	while(!feof(p_book)){
		fscanf(p_book,b_list,&tmp2.price,&tmp2.number,&tmp2.isbn,tmp2.book_name,tmp2.book_auteur,&tmp2.publish_date.year,&tmp2.publish_date.month,&tmp2.publish_date.day);
		if(number==tmp2.number){
			if(credits2>=tmp2.price){
				credits2-=tmp2.price;
				FILE * p_new_credits=fopen(c,"w+");
				fprintf(p_new_credits,"%d\n",credits2);
				fclose(p_new_credits);
				FILE * p_client_books=fopen(d,"r+");
				fseek(p_client_books,0,SEEK_END);
				fprintf(p_client_books,"%d / 1\n",tmp2.number);
				
				color(0,2);
				printf("You did it!\nYou can now read this book at anytime.\n\n");  //success
				color(0,15);
				
				fclose(p_client_books);
				free(c);
				free(d);
				free(tmp2.book_auteur);
				free(tmp2.book_name);
				fclose(p_book);
				return 0;
			}
			else {
				color(0,6);
				printf("You Don't Have enough credits!!\n\n");  //credits are below the book's price
				color(0,15);
				
				free(c);
				free(d);
				free(tmp2.book_auteur);
				free(tmp2.book_name);
				fclose(p_book);
				return 1;
			}
			
		}
	}
	free(c);
	free(d);
	free(tmp2.book_auteur);
	free(tmp2.book_name);
	fclose(p_book);
	
	color(0,6);
	printf("Book not Found!!\n\n");
	color(0,15);
	
	return 1;
}


int add_client_credits(client clt){  //add 60 credits for every new client
	char c[ch+12];
	strcpy(c,clt.username);
	
	char *d=complete_credits_file(c);
	
	FILE * p=fopen(d,"w");
	free(d);
	fprintf(p,"%d\n",credits);
	fclose(p);
}


int show_client_credits(client clt){  //show how much credits the client has
	clear();
	int i,j;
	char c[ch+12];
	strcpy(c,clt.username);
	char *d=complete_credits_file(c);
	FILE * p=fopen(d,"r");
	free(d);
	int crds;
	fscanf(p,"%d\n",&crds);
	fclose(p);
	printf("\nYou Have ");
	
	if(crds>=10)color(0,2);
	else color(0,6);
	printf("%d ",crds);
	color(0,15);
	
	printf("Credits Remaining!!\n\n");
}


int add_client_books(client clt){  //add a file like './client_books/username.txt'

	int i,j;
	char c[40];
	strcpy(c,clt.username);
	
	char *d=complete_book_file(c);
	
	FILE * p=fopen(d,"w");
	free(d);
	fclose(p);
	return 0;
}


int add_client(client clt){  //add client to the list
    FILE * p_client=fopen(clients_open,"r+");
    fseek(p_client,0,SEEK_END);
    fprintf(p_client,"%d / %s / %s / %s / %s\n",set_number(),clt.nom,clt.prenom,clt.username,clt.password);
    fclose(p_client);
    return 0;
}


int client_signup(){  //new client sign up
	clear();
	int try_again=0;
	    client clt;
	    clt.nom=(char*)malloc(sizeof(char)*ch);
	    clt.prenom=(char*)malloc(sizeof(char)*ch);
	    clt.username=(char*)malloc(sizeof(char)*ch);
	    clt.password=(char*)malloc(sizeof(char)*33);
	    
	    do{
        printf("Enter Username: ");
        scanf("%s",clt.username);
        if(strcmp(clt.username,"admin")==0){  //'admin' is reserved to the admin
        	color(0,6);
        	printf("You can't Sign up as Admin!\n\n");
        	color(0,15);
        	return;
		}
        if(test_user(clt.username)!=NULL){  //test if the username is already exits
            
            color(0,6);
            printf("Username already in use!\n");
            color(0,15);
            
            printf("Try Again? yes(1) no(2) : ");
            scanf("%d",&try_again);
            clear();
            if(try_again!=1){
            	free(clt.nom);
	            free(clt.password);
	            free(clt.prenom);
	            free(clt.username);
            	return;
			}
            }
            
            else break;
			}while(try_again==1);
        
        
        int i;
        try_again=0;
            do{
			printf("Enter Password: ");
            char * pass_login=test_passwd();
    		if(pass_login==NULL){
    			clear();
    			
    			
	            free(clt.password);
	            free(clt.username);
				free(pass_login);
    			return 1;
			}
			printf("Confirm Password: ");
			char * pass_login2=test_passwd();
			if(strcmp(pass_login,pass_login2)==0){
				getchar();
	    printf("Enter Lastname: ");
        gets(clt.nom);
        space_to_(clt.nom);
        printf("Enter Firstname: ");
        gets(clt.prenom);
        space_to_(clt.prenom);
            strcpy(clt.password,pass_login);
            add_client(clt);
            add_client_books(clt);
            add_client_credits(clt);
            
            free(pass_login);
            free(pass_login2);
	        free(clt.password);
	        
	        free(clt.username); 
	        
            clear();
            
            color(0,2);
            printf("You Have Successfully Signed Up!\n\n");
            color(0,15);
            
            return 0;
            }
            else {
            	color(0,6);
            	printf("The Two Passwords are not the same!\n");
            	color(0,15);
            	
            	printf("Try Again? (1)yes  (2)no\n->");
            	scanf("%d",&try_again);
			}
    }while(try_again==1);
}


int last_removed(){  //search for the biggest number in removed clients
	FILE * p_removed_client=fopen("./clients/removed_clients.txt","r");
	int tmp;
	fseek(p_removed_client,0,SEEK_END);
	int a=ftell(p_removed_client);
	fseek(p_removed_client,0,SEEK_SET);
	int b=ftell(p_removed_client);
	if (a==b)return 1;
	int test=0;
	while(!feof(p_removed_client)){
		fscanf(p_removed_client,"%d / %*s / %*s / %*s / %*s\n",&tmp);
		if(test<tmp)test=tmp;
	}
	fclose(p_removed_client);
	return test+1;
}


int last_client(){  //search for the biggest number in existing clients
	FILE * p_client=fopen(clients_open,"r");
	int tmp;
	fseek(p_client,0,SEEK_END);
	int a=ftell(p_client);
	fseek(p_client,0,SEEK_SET);
	int b=ftell(p_client);
	if (a==b)return 1;
	int test=0;
	while(!feof(p_client)){
		fscanf(p_client,"%d / %*s / %*s / %*s / %*s\n",&tmp);
		if(test<tmp)test=tmp;
	}
	fclose(p_client);
	return test+1;
}


int set_number(){  //client's number is auto increment
	return last_removed()>last_client() ? last_removed():last_client();
}


void removed_users(client removed_user){  //add removed client to removed_clients.txt
	FILE * p_client=fopen("./clients/removed_clients.txt","r+");
	fseek(p_client,0,SEEK_END);
	fprintf(p_client,"%d / %s / %s / %s / %s\n",removed_user.num_client,removed_user.nom,removed_user.prenom,removed_user.username,removed_user.password);
	fclose(p_client);
}


int show_client_books(char *user){  //show all client's books
	int i,j;
	char *d=complete_book_file(user);
	FILE * p=fopen(d,"r");

	FILE * p_book=fopen("./books/books_list.txt","r");
	int num,progress;
	book tmp;
	tmp.book_auteur=(char*)malloc(sizeof(char)*size);
	tmp.book_name=(char*)malloc(sizeof(char)*size);
	int count=1;
	
	fseek(p,0,SEEK_END);
	int end=ftell(p);
	fseek(p,0,SEEK_SET);
	int set=ftell(p);
	if(set==end){
		printf("You Don't have any books yet\n");
		return;
	}
	
	while(!feof(p)){
		fscanf(p,"%d / %d\n",&num,&progress);
		fseek(p_book,0,SEEK_SET);
		while(!feof(p_book)){
			fscanf(p_book,b_list,&tmp.price,&tmp.number,&tmp.isbn,tmp.book_name,tmp.book_auteur,&tmp.publish_date.year,&tmp.publish_date.month,&tmp.publish_date.day);

			if(tmp.number==num){

				int tmp_count=count,count_tmp_count=0;
				while(tmp_count!=0){
					tmp_count/=10;
					count_tmp_count++;
				}
				for(tmp_count=0;tmp_count<9+count_tmp_count;tmp_count++){
					printf("-");
				}
				printf("\n| Book %d |\n",count);
				for(tmp_count=0;tmp_count<9+count_tmp_count;tmp_count++){
					printf("-");
				}
				_to_space(tmp.book_auteur);
				_to_space(tmp.book_name);
				printf("\nNumber-> %d\nISBN-> %lld\nName-> %s\nAuthor-> %s\nPublish Date-> %d/%d/%d\nPrice-> | %d |\n\nProgress-> %d\n\n\n\n",tmp.number,tmp.isbn,tmp.book_name,tmp.book_auteur,tmp.publish_date.year,tmp.publish_date.month,tmp.publish_date.day,tmp.price,progress);
				count++;
				break;
			}
		}
	}
	if(count==1){
		
		color(0,6);
		printf("You don't Have Any Books Yet!\nBuy Books using your credits.\n");
		color(0,15);
		
	}
	free(tmp.book_auteur);
	free(tmp.book_name);
	fclose(p);
	fclose(p_book);
	return 0;
}


typedef struct discv{  //application of 'listes chain�es'
		book b;
		struct discv *next;
}discv;


discv *init_liste(discv *L){  //initialisation of list
	L=NULL;
	return L;
}


discv *ajouter_en_tete(discv *L,FILE *p){  //add to the head
	
	
	
	discv *nv=(discv*)malloc(sizeof(discv));
	nv->b.book_auteur=(char*)malloc(sizeof(char)*size);
	nv->b.book_name=(char*)malloc(sizeof(char)*size);
	
	fscanf(p,b_list,&nv->b.price,&nv->b.number,&nv->b.isbn,nv->b.book_name,nv->b.book_auteur,&nv->b.publish_date.year,&nv->b.publish_date.month,&nv->b.publish_date.day);
	_to_space(nv->b.book_auteur);
	_to_space(nv->b.book_name);
	nv->next=L;
	
	return nv;
	
}


int Discover(client *clt){
	clear();
	discv *L;
	L=init_liste(L);
	
	
	
	
	FILE  * p=fopen(b_list_open,"r");
	fseek(p,0,SEEK_END);
	int end=ftell(p);
	fseek(p,0,SEEK_SET);
	int set=ftell(p);
	if(set==end){  //test if the file is empty
		clear();
		printf("There's No Books At This Time!\n\n");
		return;
	}
	while(!feof(p)){
		L=ajouter_en_tete(L,p);
		
	}
	fclose(p);
	discv* tmp=L;
	while(1){
		
	
	if(L==NULL)L=tmp;
	printf("\nNumber-> %d\nISBN-> %lld\nName-> %s\n"
	"Author-> %s\nPublish Date-> %d/%d/%d\n"
	"Price-> | %d |\n\n\n",L->b.number,L->b.isbn,L->b.book_name,L->b.book_auteur,L->b.publish_date.year,L->b.publish_date.month,L->b.publish_date.day,L->b.price);
	
	int stop=0;
	int choice;
	
	do{
		color(0,14);
	printf("(1)Show Next  (2)Select  (3)Stop\n->");
	scanf("%d",&choice);
	clear();
	    color(0,15);
	    
	switch(choice){
		
	case 1:  stop=1; break;
	case 2:  stop=1; search_online(clt,L->b.number); break;
	case 3:  stop=1; break;
	default: stop=0; color(0,6); printf("Please Choose from the List!\n"); color(0,15); break;
                 
				 }
	}while(stop==0);
	
	if(choice==3) {
		clear();
		break;
	}
	
	if(choice==1)L=L->next;
		}
	
	return;
}


int remove_user_data(char *user){  //remove client's books and credits
	int i,j;
	char c[ch];
	char e[ch];
	strcpy(c,user);
	strcpy(e,user);
	char *d=complete_book_file(c);
	remove(d);
	d=complete_credits_file(e);
	remove(d);
	
}


int remove_user(){  //remove client
	char user_delete[ch];
		printf("Enter Username: ");
		scanf("%s",user_delete);
		clear();
	if(test_user(user_delete)==NULL){
		
		color(0,6);
		printf("Username does not exist!\n\n\n");
		color(0,15);
	}
	else{
		FILE * p_client=fopen(clients_open,"r");;
		FILE * p_new=fopen("./clients/2clients.txt","w");
		
		client clt_delete;
		
		
		clt_delete.nom=(char*)malloc(sizeof(char)*ch);
		clt_delete.prenom=(char*)malloc(sizeof(char)*ch);
		clt_delete.username=(char*)malloc(sizeof(char)*ch);
		clt_delete.password=(char*)malloc(sizeof(char)*33);
		
		
	
		
		
		while(!feof(p_client)){
			fscanf(p_client,"%d / %s / %s / %s / %s\n",&clt_delete.num_client,clt_delete.nom,clt_delete.prenom,clt_delete.username,clt_delete.password);
			if(strcmp(user_delete,clt_delete.username)==0){
				 removed_users(clt_delete);
			}
			else{
				fprintf(p_new,"%d / %s / %s / %s / %s\n",clt_delete.num_client,clt_delete.nom,clt_delete.prenom,clt_delete.username,clt_delete.password);
			}
			}
		
		fclose(p_client);
		fclose(p_new);
		int rm=remove(clients_open);
		if(rm!=0){
			
			color(0,4);
			printf("Deleting file is Impossibile!\n\n");
			color(0,15);
			
			free(clt_delete.nom);
			free(clt_delete.password);
			free(clt_delete.prenom);
			free(clt_delete.username);
			
			
		    
		    
		    return 1;
		}
		int ren=rename("./clients/2clients.txt",clients_open);
		if(ren!=0){
			
			color(0,4);
			printf("Renaming file is Impossibile!\n\n");
			color(0,15);
			
			free(clt_delete.nom);
			free(clt_delete.password);
			free(clt_delete.prenom);
			free(clt_delete.username);
			
			
		    return 1;
		}
		remove_user_data(user_delete);
		
		color(0,2);
	    printf("User removed successfully!\n\n");
	    color(0,15);
	    
		    free(clt_delete.nom);
			free(clt_delete.password);
			free(clt_delete.prenom);
			free(clt_delete.username);
			
		
	return 0;
		}
		
	    
	}





void showing_users(FILE * p_client){  //showing clients informations for the admin
	
	int count=0;
	fseek(p_client,0,SEEK_END);
	int out=ftell(p_client);
	fseek(p_client,0,SEEK_SET);
	int in=ftell(p_client);
	if(in==out){
		color(0,6);
		printf("Empty Set!\n");
		color(0,15);
	}
	else{
	
	color(0,14);
	printf("Number:      Lastname:            Firstname:           Username:            Password:                       |\n"
	"____________________________________________________________________________________________________________|\n\n");
	color(0,15);
	
	client tmp;
	
	tmp.nom=(char*)malloc(sizeof(char)*ch);
	tmp.password=(char*)malloc(sizeof(char)*33);
	tmp.prenom=(char*)malloc(sizeof(char)*ch);
	tmp.username=(char*)malloc(sizeof(char)*ch);
	
	while(!feof(p_client)){
		fscanf(p_client,"%d / %s / %s / %s / %s\n",&tmp.num_client,tmp.nom,tmp.prenom,tmp.username,tmp.password);
		_to_space(tmp.nom);
		_to_space(tmp.prenom);
		int a=tmp.num_client;
		while(a!=0){
			a/=10;
			count++;
		}
		int i;
		printf("%d:",tmp.num_client);
		for(i=0;i<(12-count);i++){
			printf(" ");
		}
		count=0;
		printf("%s",tmp.nom);
		for(i=0;i<(21-strlen(tmp.nom));i++){
			printf(" ");
		}
		printf("%s",tmp.prenom);
		for(i=0;i<(21-strlen(tmp.prenom));i++){
			printf(" ");
		}
		printf("%s",tmp.username);
		for(i=0;i<(21-strlen(tmp.username));i++){
			printf(" ");
		}
		printf("%s\n",tmp.password);
		
		
	}
	free(tmp.nom);
	free(tmp.password);
	free(tmp.prenom);
	free(tmp.username);
	}
	
}


void show_existed_users(){  //show existing clients
	FILE * p_client=fopen(clients_open,"r");
	showing_users(p_client);
	fclose(p_client);
}


void show_removed_users(){  //show deleted clients
	FILE * p_client=fopen("./clients/removed_clients.txt","r");
	showing_users(p_client);
	fclose(p_client);
}


void show_users(int number){  //show clients
	clear();
	
	if(number==1)show_existed_users();
	else if(number==2)show_removed_users();
	printf("\n\n");
}



