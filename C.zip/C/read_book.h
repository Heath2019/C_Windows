#define lines 20  //lines of every page


int max_lines;
int position;

char **container(int number){

char *c=set_book_file(number);
	FILE * p=fopen(c,"r");
	


char *counter=(char*)malloc(sizeof(char)*max_book);

while(fgets(counter,max_book,p)!=NULL){
	
	if(strcmp(counter,description_line)==0)break;      //Skip The Book's Description
}
int i=0;
while(fgets(counter,max_book,p)!=NULL){
	i++;
}
free(counter);
max_lines=i;
char **mat=(char**)malloc(sizeof(char*)*max_lines);

for(i=0;i<max_lines;i++){
	mat[i]=(char*)malloc(sizeof(char)*max_book);
}
if(mat==NULL) return NULL;

i=0;

char *test=(char*)malloc(sizeof(char)*max_book);

fseek(p,0,SEEK_SET);
while(fgets(test,max_book,p)){
	if(strcmp(test,description_line)==0)break;
}
while(fgets(test,max_book,p)!=NULL){
	strcpy(mat[i],test);
	i++;
}
fclose(p);
return mat;
}


int start(char **mat){
	int k;
	k=(position-1)*lines;  //page 1 -> mat[0] to mat[19] / page 2 ->mat[20] to mat[39] ...
	
	int i=0,l=position;
	while(l!=0){
		l/=10;
		i++;
	}
	clear();
	l=i;
	if(l==1)l=2;
	
	system("color F0");  //set the console color to white
	
	color(6,15);      //text background to blue
	
	for(i=0;i<max_book-1;i++){
		printf(" ");
	}
	printf("\n");
	
	for(i=0;i<(max_book-l-5)/2;i++){
		printf("-");
	}
	printf("Page %d",position);
	for(i=0;i<(max_book-l-4)/2;i++){
		printf("-");
	}
	printf("\n");
	for(i=0;i<max_book-1;i++){
		printf(" ");
	}
	
	printf("\n\n");
	
	color(15,0);    //reset the colors to default
	
	if(position>max_lines/lines){
		for(i=k;i<k+max_lines%lines;i++){
		if(mat[i]!=NULL) printf("%s",mat[i]);
		}
	}
	else for(i=k;i<k+lines;i++){
		if(mat[i]!=NULL)printf("%s",mat[i]);
	}
	
}


int next(){  //move to the next page
	
	position++;
	
	if(max_lines%lines==0){
		if(position>max_lines/lines)position--;
	}
	else{
		if(position>(max_lines/lines)+1)position--;
	}

}


int previous(){  //go back to the previous page
	if(position>1)
	position--;
	
}


int read_book(char *user,int number,int progress){
	
	if(strcmp(user,"admin")!=0){
	FILE *p=fopen(b_list_open,"r");
	int tmp=1;
	while(!feof(p)){
		fscanf(p,"$ %*s / %d / %*s / %*s / %*s / %*s - %*s - %*s\n",&tmp);
		if(number==tmp){
			tmp=0;
			break;
		}
	}
	fclose(p);
	if(tmp!=0){
		printf("Sorry But This Book is not Available Anymore!\n");
		return 1;
	}
	  
	}
	printf("\n");
	position=progress;  //start from saved position
	char **mat=container(number);
	
	
	
	
	start(mat);
	
	
	
	int loop=0;
	int i;
	int choice;
	do{
	if(max_lines<=lines)printf("(3)Quit\n->");
	else{
	if(position==1) printf("(1)Next  (3)Quit\n->");
	else if(position>max_lines/lines&&max_lines%lines!=0) printf("(2)Previous  (3)Quit\n->");
	else if(position==max_lines/lines&&max_lines%lines==0) printf("(2)Previous  (3)Quit\n->");
	else printf("(1)Next  (2)Previous  (3)Quit\n->");
	}
	scanf("%d",&choice);
	switch(choice){
	case 1: next();
	start(mat);
	break;
	case 2: previous();
	start(mat);
	break;
	case 3: 
	
	
	loop=1;
	system("color 0F");
	int a;
	if(strcmp(user,"admin")!=0){
		
	if(position==1&&progress==1){
		system("color 0F");
		loop=1;
		break;
	}
	else if(position==progress){
		system("color 0F");
		loop=1;
		break;
	}
	else{
		printf("Save Progress? (1)yes  (2)no\n->");
	    scanf("%d",&a);
	    system("color 0F");
	    if(a!=1)position=1;
	    else{
		progress=position;                   
		save_progress(user,number,progress);  //save last position
		
	}
}
	}
	
	
	break;
	default: printf("Please Choose from the list.\n");break;
    }
	}while(loop==0);
	
	clear();
	
	int v;
		printf("Write a Comment?\n->(1)yes  (2)no\n->");
		scanf("%d",&v);
		if(v==1) add_comment(user,number);
	return 0;
}


int save_progress(char *user,int number,int progress){  //save progress of reading
	char *c=complete_book_file(user);
	FILE * p=fopen(c,"r");
	FILE * p_new=fopen("tmp.txt","w+");
	int one,two;
	while(!feof(p)){
		fscanf(p,"%d / %d\n",&one,&two);
		if(number==one) fprintf(p_new,"%d / %d\n",one,progress);
		else fprintf(p_new,"%d / %d\n",one,two);
	}
	fclose(p);
	fclose(p_new);
	remove(c);
	rename("tmp.txt",c);
	return;
}


int read_description(int number){  //read description
	char *c=set_book_file(number);
	FILE * p=fopen(c,"r");
	free(c);
	char *tmp=(char*)malloc(sizeof(char)*max_book);
	
	int i=0;
	while(fgets(tmp,max_book,p)!=NULL){
		if(strcmp(tmp,description_line)==0)break;
		i++;
	}
	
	if(i==0){
		printf("There's No Description for this Book!\n\n");
		fclose(p);
		free(tmp);
		return 1;
	}
	else{
		char **mat=(char**)malloc(sizeof(char*)*i+1);
		int j;
		for(j=0;j<i+1;j++){
			mat[j]=(char*)malloc(sizeof(char)*max_book);
		}
		fseek(p,0,SEEK_SET);
		
		j=0;
		
		while(fgets(tmp,max_book,p)){
			if(strcmp(tmp,description_line)==0){
				mat[j]=NULL;
				
				break;
			}
			strcpy(mat[j],tmp);
			j++;
		}
		fclose(p);
		free(tmp);
		
		j=0;
		while(mat[j]!=NULL){
			printf("%s",mat[j]);
			j++;
		}
	}
	
}
