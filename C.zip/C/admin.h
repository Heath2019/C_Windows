typedef struct administrator{  //admin structure
    char name[10];
    char *username;
    char *password;
}administrator;


int signed_in=0;  //for saving admin's session


int test_admin(char *user,char *pass){  //test if the admin username and password are correct
	FILE * p_admin;
	p_admin=fopen("admin.txt","r");
	
	administrator admin_test;
	admin_test.password=(char*)malloc(sizeof(char)*33);
	admin_test.username=(char*)malloc(sizeof(char)*ch);
	
		fscanf(p_admin,"%s / %s / %*s\n",admin_test.username,admin_test.password);
		if(strcmp(user,admin_test.username)!=0) {
			fclose(p_admin);
			free(admin_test.password);
		    free(admin_test.username);
			return 1;
		}
		else{
			if(strcmp(pass,admin_test.password)!=0){
				fclose(p_admin);
				free(admin_test.password);
		      	free(admin_test.username);
				return 1;
			}
			else {
			    fclose(p_admin);
				free(admin_test.password);
		      	free(admin_test.username);
				
				signed_in=1;  //save session of admin for the next log in
				return 0;
			}
		}
	
}


int admin_portal(){
	clear();
	int a,stop=0;
	printf("-----------------\n| Admin Portal! |\n-----------------\n");
	while(stop==0){
	printf("(1)show all the users\n(2)remove a user\n(3)Show Deleted Users\n(4)Search a book\n(5)show all the books\n(6)add a book\n(7)Delete a Book\n(8)Change Password\n(9)Logout\n->");
	scanf("%d",&a);
	switch(a){
	case 1: show_users(1);break;
	case 2: remove_user();break;
	case 3: show_users(2);break;
	case 4: 
	printf("");
	int res=search_book();
	//res=0 when user has searched with name and res=number when searched by number
	if(res!=0){
		int choice,stop=0;
		clear();
		do{
			
			search_book_by_number(res);
		printf("(1)Read\n(2)Read Description\n(3)Read Comments\n(4)Remove Book\n(5)Stop\n->");
		scanf("%d",&choice);
		
		switch(choice){
			case 1: 
			read_book("admin",res,1); 
			color(0,15);
			break;
			case 2: clear(); read_description(res); break;
			case 3: clear(); read_book_comments(res); break;
			case 4: delete_book(res); stop=1; break;
			case 5: clear(); stop=1; break;
			default: 
			clear();
			color(0,6);
			printf("Please Choose from the List!\n"); 
			color(0,15);
			break;
		}}while(stop==0);
	}
	
	break;
	case 5: show_all_books();break;
	case 6: add_book();break;
	case 7: printf("Enter the book's number: ");
	scanf("%d",&a);
	delete_book(a);break;
	case 8: change_admin_pass(); break;
	
	case 9:
		clear();
		color(0,2);
		printf("Logout Successful!\n\n");
		color(0,15);
		
		signed_in=0;  //end session
		stop=1;
		return 1;break;
	default: clear();
	color(0,6);
	printf("Please choose from the list\n");
	color(0,15);
	break;
	}
}
	return 0;
}


int admin_signin(){
	clear();
	int loop=0;
		char *admin_user=(char*)malloc(sizeof(char)*30);
		
		printf("Admin Sign in!\n");
	    printf("Enter Username: ");
	    scanf("%s",admin_user);
	    printf("Enter Password: ");
	    char *admin_pass=test_passwd();  //call the password function
	    if(test_admin(admin_user,admin_pass)==0){
	    	int r;
	    	
			color(0,2);
	    	printf("Login Successfull!\n");
	    	color(0,15);
	    	
	    	printf("Enter Portal? (1)yes  (2)no\n->");
	    	scanf("%d",&r);
	    	
	    	clear();
	    	if(r==1){
	    		if(admin_portal()==1){  //enter admin's portal
				loop=1;
				
				
				}
			}
	    	else {
	    		loop=1;
			
		}
		clear();
		
		}
		else {
			color(0,6);
			printf("Username or Password is Incorrect!\n\n");
			color(0,15);
		}
}


int change_admin_pass(){  //change admin's password
	clear();
	
	FILE * p=fopen("admin.txt","r");
	char *user=(char*)malloc(sizeof(char)*ch);
	char *name=(char*)malloc(sizeof(char)*10);
	
	
		fscanf(p,"%s / %*s / %s\n",user,name);
	
	fclose(p);
	printf("Enter Your Current Password: ");  //current pass
	char *test=test_passwd();
	FILE *p_test=fopen("admin.txt","r");
	char *tmp_pass=(char*)malloc(sizeof(char)*33);
	fscanf(p_test,"%*s / %s / %*s\n",tmp_pass);  //test if the pass is correct
	fclose(p_test);
	if(strcmp(test,tmp_pass)==0) {
	
	printf("Enter the New Password: ");
	char *pass=test_passwd();
	
	if(strcmp(pass,tmp_pass)==0){
			color(0,6);
			printf("Cannot Change Password With itself!\n\n");  //cannot change password wth itself
			color(0,15);
			return 1;
	}
		
	printf("Confirm Password: ");
	char *pass2=test_passwd();
	
	clear();
	
	if(strcmp(pass,pass2)==0){  //allow changing password after confirming
		
	    
	    
	    	FILE * p_new=fopen("admin.txt","w+");
	        fprintf(p_new,"%s / %s / %s\n",user,pass,name);
	        fclose(p_new);
	        color(0,2);
	        printf("Password Changed Succesfully!\n\n");
	        color(0,15);
		
	}
	else {
		color(0,6);
		printf("the two Passwords are not the Same!\n\n");
		color(0,15);
	}
	return 1;
	}
	else {
		clear();
		color(0,6);
		printf("Password is Incorrect!\n\n");
		color(0,15);
		return 1;
	}
	return 0;
}


