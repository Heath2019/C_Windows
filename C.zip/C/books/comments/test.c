#include<stdio.h>
#include<stdlib.h>
#include<string.h>


typedef struct comments{
	char *user;
	char **cmt;
	struct comments *next;
}comments;

comments *init_cmt(comments *L){
	L=NULL;
	return L;
}


comments *ajouter_cmt_en_tete(comments *L,char *user,char **cmt){
	comments *nv=(comments*)malloc(sizeof(comments));
	nv->user=(char*)malloc(sizeof(char)*30);
	nv->cmt=(char**)malloc(sizeof(char*)*30);
	int i;
	strcpy(nv->user,user);
	for(i=0;i<30;i++){
		nv->cmt[i]=(char*)malloc(sizeof(char)*100);
		if(cmt[i])strcpy(nv->cmt[i],cmt[i]);
		else nv->cmt[i]=NULL;	
	}
	nv->cmt[i]=NULL;
	nv->next=L;
	return nv;
}


main(){
	FILE *p=fopen("2_comments.txt","r");
	char*tmp=(char*)malloc(sizeof(char)*100);
	char* user=(char*)malloc(sizeof(char)*30);
	char **mat=(char**)malloc(sizeof(char*)*30);
	int i;
	
	
	
	
	for(i=0;i<30;i++){
		mat[i]=(char*)malloc(sizeof(char)*100);
	}
	i=0;
	int j;
	comments *L=init_cmt(L);
	while(fgets(tmp,100,p)){
		if(strstr(tmp,"/user/")!=0){
			
			j=7;
			while(tmp[j]!=' '){
				user[j-7]=tmp[j];
				j++;
			}
			user[j-7]='\0';
			
		}
		else if(strcmp(tmp,"/89/comment!/89/\n")==0){
			mat[i]=NULL;
			i=0;
			L=ajouter_cmt_en_tete(L,user,mat);
		}
		else{
			
			strcpy(mat[i],tmp);
			
		    i++;
		}
		
	}
	
	fclose(p);
	i=0;
	
	while(L){
		printf("\n\nUser: %s\n",L->user);
		printf("Comment: \n");
		i=0;
		while(L->cmt[i]){
			printf("%s",L->cmt[i]);
			i++;
		}
		L=L->next;
	}
	
}
