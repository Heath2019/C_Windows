/*

the problem we facing here is that the fscanf function doesn't accept spaces in strings.
so what we got to do is not putting any spaces in our files,
instead, turning the spaces into '+' when creating file; space_to_
turn the '+' into spaces when reading file; _to_space

*/

char *space_to_(char *c){
	int i;
	for(i=0;i<50;i++){
		if(c[i]=='\0')break;
		if(c[i]==' ')c[i]='+';
	}
	return c;
}


char* _to_space(char *c){
	int i;
	for(i=0;i<50;i++){
		if(c[i]=='\0')break;
		if(c[i]=='+')c[i]=' ';
	}
	return c;
}


